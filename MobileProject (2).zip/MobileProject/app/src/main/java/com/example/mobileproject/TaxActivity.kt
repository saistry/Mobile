package com.example.mobileproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.view.View
import kotlinx.android.synthetic.main.activity_tax.*

class TaxActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tax)
        var N1= amount.text
        var N2= percent.text
        calculateTotal.setOnClickListener {

            var result = ((N1.toString().toDouble() * (N2.toString().toDouble())) * .01) + N1.toString().toDouble()
            totalPrice.text = (Math.round(result * 100.0) / 100.0).toString()
        }}

}