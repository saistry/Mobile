package com.example.mobileproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.content.SharedPreferences
import android.text.TextUtils
import androidx.core.content.ContextCompat.startActivity
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_preferences.*


class MainActivity : AppCompatActivity() {




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        PREF_name="name"
        var databack: SharedPreferences = getSharedPreferences(PREF_name, 0)
        if (databack.contains("message")){
            nameSaved.text=databack.getString("message", "not found")
        }
    }

    fun gotax(view: View){
        val tax = findViewById<Button>(R.id.tax)
            val taxIntent = Intent(this, TaxActivity::class.java)
            startActivity(taxIntent)
        }
    fun gotip(view: View){
        val tip = findViewById<Button>(R.id.tip)
                val tipIntent = Intent(this, TipActivity::class.java)
                startActivity(tipIntent)
        }

    fun gohelp(view: View){
        var help = findViewById<Button>(R.id.help)
            val helpIntent = Intent(this, TheHelpActivity::class.java)
            startActivity(helpIntent)

    }
    fun gopreferences(view: View){
        var preferences = findViewById<Button>(R.id.preferences)
            val preferencesIntent = Intent(this, PreferencesActivity::class.java)

            startActivity(preferencesIntent)

}}