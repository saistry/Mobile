package com.example.mobileproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.view.View
import kotlinx.android.synthetic.main.activity_preferences.*
import android.text.TextUtils
import android.content.SharedPreferences



var PREF_name="name"
class PreferencesActivity : AppCompatActivity() {

            fun savePreferences(view: View){
                var PREF_name="name"
                var myPref = getSharedPreferences(PREF_name,0)
                var editor: SharedPreferences.Editor = (myPref as SharedPreferences).edit()

                if (TextUtils.isEmpty(PREF_name)) {
                    editor.putString("message", "notfound")
                }else {
                    editor.putString("message", nameinput.text.toString())
                }
                editor.commit()

            }
}