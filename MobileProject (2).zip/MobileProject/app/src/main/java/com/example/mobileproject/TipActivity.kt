package com.example.mobileproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.view.View
import kotlinx.android.synthetic.main.activity_tip.*

class TipActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tip)
        var N1= amount.text
        var N2= percent.text
        calculateTotal.setOnClickListener {

            var result = N1.toString().toDouble() * N2.toString().toDouble() * .01
            totalPrice.text = (Math.round(result * 100.0) / 100.0).toString()
        }}

    }
